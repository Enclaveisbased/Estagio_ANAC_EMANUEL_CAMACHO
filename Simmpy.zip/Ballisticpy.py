import numpy as np
import scipy.constants as sc
import math
import matplotlib.pyplot as plt 
import scipy.integrate
import Unitconversions as cf
from scipy.optimize import fsolve
g = 9.81
def trajectoryprediction(Psl, Tsl, crafthdg, Whdg, Wspdkt, draft, maxhor, Windres, hmax, Endhours, Endkm, M, Cd, phi):

    

    # Atmospheric conditions calculation based on SL values
    Tslk = Tsl + 273.15
    P = Psl * 100 * (1 - (hmax * 0.0065 / 288.15))**5.25588
    Tk = Tslk - 0.0065 * hmax
    A = 0.010
    a = 340.294 * np.sqrt(Tk / 288.15)
    rho = P / (287.052874 * Tk)

    #Wind adjustment

    ex_craft = np.sin(np.deg2rad(crafthdg))
    ey_craft = np.cos(np.deg2rad(crafthdg))
    ez_craft = 0
    x_wind = Wspdkt * np.sin(np.deg2rad(Whdg))
    y_wind = Wspdkt * np.cos(np.deg2rad(Whdg))
    z_wind = draft
    wind = np.array([x_wind, y_wind, draft])

    #Initial conditions

    vx0, vy0, vz0 = ex_craft*maxhor-wind[0], ey_craft*maxhor-wind[1], 0 - wind[2]

    Groundspeed0 = [ex_craft*maxhor-x_wind, ey_craft*maxhor-y_wind]

    k = 0.5*rho*Cd*A

    #Motion equations
    
    tins = np.arange(0, 300, 0.5)

    vhor = 1/((1/(np.linalg.norm([vx0, vy0])))+k*tins/M)

    vz = -np.sqrt(M*g/k)*np.tanh(np.sqrt(k*g/M)*tins)

    dhor = (M*np.log(k*np.linalg.norm([vx0, vy0])+M))/k

    dz = -(M/k)*np.log(np.cosh(np.sqrt(k*g/M)*tins))+hmax
    
    dx = dhor*np.cos(np.angle([vx0, vy0]))

    print(dhor)

    dy = dhor*np.sin(np.angle([vx0, vy0])) 


    #Important quantities

    terminalv = -np.sqrt(M*g/k)

    falltime = np.arccosh(np.e**(hmax*k/M))*np.sqrt(M/(g*k))

    Dx = 0.5*rho*vhor*Cd*ex_craft
    Dy = 0.5*rho*vhor*Cd*ey_craft
    Dz = 0.5*rho*vz*Cd


    Total_Force = [ex_craft*Dx, ey_craft*Dy, Dz-g*M]

    velocity = [vhor*ex_craft, vhor*ey_craft, vz]








    return (falltime, terminalv)