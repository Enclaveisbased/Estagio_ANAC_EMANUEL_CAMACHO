import numpy as np
import sys
import os
import pandas as pd
import scipy.constants as sc
import matplotlib.pyplot as plt
import Unitconversions as cf
import Glidecharpy
import Ballisticpy
file_path = 'ESTUDO DE MERCADO UAS.xlsx'
df = pd.read_excel(file_path, sheet_name='Sheet1')  

copter = []
fixedwing = []

start_index = 91
end_index = min(119, df.shape[0]) 

for i in range(start_index, end_index):
    if pd.notna(df.iloc[i, 0]):  
        data_row = [
            df.iloc[i, 0], # Name
            df.iloc[i, 14],  # Ceiling
            df.iloc[i, 16],  # Endurance
            df.iloc[i, 22],  # MTOM
            df.iloc[i, 26],  # AR
            df.iloc[i, 28],  # Wing Area
            df.iloc[i, 40],  # Cd0
            df.iloc[i, 42], # Oswald efficiency factor  
        ]
        
        fixedwing.append(data_row)

start_index = 6
end_index = min(32, df.shape[0]) 

for i in range(start_index, end_index):
    if pd.notna(df.iloc[i, 0]):  
        data_rowquad = [
            df.iloc[i, 0], # Name
            df.iloc[i, 6],  # Max speed hor
            df.iloc[i, 10],  # Max wind resistance
            df.iloc[i, 14],  # Ceiling
            df.iloc[i, 16],  # Endurance hours
            df.iloc[i, 18],  # Endurance KM
            df.iloc[i, 22],  # MTOM(Kg)
            0.105+ float(df.iloc[i, 22])*0.087, # Cd
        ]
        
        copter.append(data_rowquad)

print (copter)

#FLYING CONDITIONS
windheading = 170
windspd = 0
draft = 0
PSL = 1013.25
TSL = 27




#AIRCRAFT POSTION AND ATTITUDE

aircrafthdg = 170
phi = 0




# print(fixedwing)
#print(fixedwing[1][1], fixedwing[1][3], fixedwing[1][4], fixedwing[1][5], fixedwing[1][6], fixedwing[1][7])

print (PSL, TSL, aircrafthdg, windheading, windspd, draft, copter[0][1], copter[0][2], copter[0][3], copter[0][4], copter[0][5], copter[0][6], copter[0][7], phi)


resultfx = Glidecharpy.glide_characteristics(PSL, TSL, aircrafthdg, windheading, windspd, draft, fixedwing[0][1], fixedwing[0][3], fixedwing[0][4], fixedwing[0][5], fixedwing[0][6], fixedwing[0][7], phi)

resultquad = Ballisticpy.trajectoryprediction(PSL, TSL, aircrafthdg, windheading, windspd, draft, copter[0][1], copter[0][2], copter[0][3], copter[0][4], copter[0][5], copter[0][6], copter[0][7], phi)


print(resultquad)

#Formato decimal do wgs84